Pliki do gry Metin2 2D Online (multiplayer z Firebase).
W pliku firebase-config.js masz ustawiony config do projektu mt2test.
Wrzuć index.html, game.js i firebase-config.js na GitHub Pages.
