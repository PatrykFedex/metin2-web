import { firebaseConfig } from './firebase-config.js';
console.log("Gra Metin2 2D Online startuje z configiem:", firebaseConfig);
